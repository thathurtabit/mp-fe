export const ErrorTitle = 'Houston, we have a problem';
export const NoItemsTitle = 'This little piggie had none';
export const NoTitle = 'Moonpig Card';
export const NoDesc = 'No description available for this item.';
export const BuyText = 'Buy Me';
export const loadDelay = 250;
