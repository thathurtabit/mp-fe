export const ON_LOAD = 'ON_LOAD';
export const STORE_RESPONSE = 'STORE_RESPONSE';
export const TOGGLE_MODAL = 'TOGGLE_MODAL';
